This lab was done on Zoom on the 4th April 2020 at 12:00.
It was recorded and published on my OneDrive.


HERE IS THE LINK: https://mcgill-my.sharepoint.com/:v:/g/personal/ridwan_kurmally_mcgill_ca/Ec1iYHkWMw5Ou4Au0xEbbfsBQ9JxTwMvWW5Y1LOpI7AP1g?e=IVsa5m


During the lab, questions were asked in the chatbox. You will not be able to see them in the video but you can refer to them in the zoom_lab/chatlog.txt file. Messages in that txt file have timestamp so you will be able to figure out which questions were asked at a particular instance.


Before starting the lab on zoom, I explained briefly about .h files. Related files in the headers folder.


Question 1 (makefile) related solution is in the q1 folder. These are the files I've used in the zoom lab.


For question 2 (git), I used my local Visual Studio Code terminal and the Zoom whiteboard. You can see both whiteboard in the video and I've also attached snapshots of the whiteboard taken by zoom during the meeting.
If you're not watching the video, I've added the complete (command-line) solution to question 2 in the q2 folder. These are screenshots from the mimi terminal (not from the zoom meeting).


NOTE: I WOULD HIGHLY ADVISE YOU TO WATCH THE zoom_labH.mp4 VIDEO TO HAVE A BETTER UNDERSTANDING OF THE LAB AND STRUCTURE OF THIS LAB FOLDER SOLUTION. THANK YOU!